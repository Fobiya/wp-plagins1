<?php

interface WPML_ST_Translations_File_Scan_Charset_Validation {
	/**
	 * @return bool
	 */
	public function is_valid();
}
