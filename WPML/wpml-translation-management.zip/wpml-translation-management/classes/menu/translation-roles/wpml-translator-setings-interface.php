<?php

interface WPML_Translator_Settings_Interface {
	/**
	 * @return string
	 */
	public function render();
}